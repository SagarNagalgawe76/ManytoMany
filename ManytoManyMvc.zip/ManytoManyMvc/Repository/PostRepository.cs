﻿using ManytoManyMvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ManytoManyMvc.Repository
{
    public class PostRepository
    {
        Post p;
        Tag t;
        public Post CreatePosts()
        {
            Post post = new Post() { Content = "Abc", Title = "Movie" };
            return post;
        }
    }
}
