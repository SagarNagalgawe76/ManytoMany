﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
namespace ManytoManyMvc.Models
{
    //public class PostDbContext : DbContext
    //{
    //    public DbSet<Post> PostItems { get; set; }
    //    public PostDbContext(DbContextOptions<PostDbContext> options) : base(options)
    //    {

    //    }
    //}
}
